package sample.ui.login_waiter;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Control;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.SkinBase;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import sample.model.SQLConnection;

import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;
import java.util.prefs.Preferences;

public class LoginController {


    @FXML
    private AnchorPane root;

    @FXML
    private JFXTextField loginTF;

    @FXML
    private JFXPasswordField passwordPF;

    @FXML
    public Text errorText;

    @FXML
    private Hyperlink cancelButton;


    @FXML
    private JFXButton loginButton;

    @FXML
    private Label exitButton;

    @FXML
    public void initialize() {
        Platform.runLater( () -> root.requestFocus() );
        errorText.setVisible(false);
    }

    @FXML
    void backToWelcome(ActionEvent event) throws IOException {
        root.getChildren().setAll((Node) FXMLLoader.load(getClass().getResource("/sample/ui/welcome/welcomeFX.fxml")));
    }

    @FXML
    void exit(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    void loginWaiter(ActionEvent event) throws IOException, SQLException {
        String login = loginTF.getText();
        String password = passwordPF.getText();
        if (!login.equals("") || !password.equals(""))
            if (SQLConnection.loginWaiter(login, password)) {
                root.getChildren().setAll((Node) FXMLLoader.load(getClass().getResource("/sample/ui/table/tableFX.fxml")));
                errorText.setVisible(false);
            } else
                errorText.setVisible(true);
    }


}
