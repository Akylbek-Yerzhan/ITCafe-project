package sample.ui.login_admin;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.util.prefs.Preferences;

public class AdminLoginController {

    @FXML
    public AnchorPane root;

    @FXML
    private Hyperlink cancelButton;

    @FXML
    private JFXPasswordField passwordPF;

    @FXML
    private JFXTextField loginTF;

    @FXML
    private JFXButton redButton;

    @FXML
    private Label exitButton;


    @FXML
    void backToWelcome(ActionEvent event) {
        try {
            root.getChildren().setAll((Node) FXMLLoader.load(getClass().getResource("/sample/ui/welcome/welcomeFX.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void exit(MouseEvent event) { System.exit(0); }

    @FXML
    void loginAdmin(ActionEvent event) {


    }

    @FXML
    public void initialize(){
    }


}
