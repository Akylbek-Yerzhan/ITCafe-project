package sample.ui.table;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Control;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import sample.model.SQLConnection;

import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import java.util.prefs.Preferences;

public class TableController {
    Preferences pref = Preferences.userRoot().node("/sample");
    String[] tables = new String[]{
            "orderButtonOne",
            "orderButtonTwo",
            "orderButtonThree",
            "orderButtonFour",
            "orderButtonFive",
            "orderButtonSix"
    };
    @FXML
    public AnchorPane root;

    @FXML
    private Label exitButton;

    @FXML
    private Text nameText;

    @FXML
    private JFXButton logoutButton;

    @FXML
    private JFXButton orderButtonOne;

    @FXML
    private JFXButton orderButtonTwo;

    @FXML
    private JFXButton orderButtonThree;

    @FXML
    private JFXButton orderButtonSix;

    @FXML
    private JFXButton orderButtonFive;

    @FXML
    private JFXButton orderButtonFour;

    @FXML
    public void initialize() throws SQLException {
        String waiterLogin = pref.get("login", "DEFAULT VALUE");
        nameText.setText(SQLConnection.getWaiterName(waiterLogin));
    }

    @FXML
    void exit(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
        System.out.println(pref.get("login", "DEFAULT VALUE") + " successfully logout!");
        pref.put("login", "");

        root.getChildren().setAll((Node) FXMLLoader.load(getClass().getResource("/sample/ui/welcome/welcomeFX.fxml")));
    }

    @FXML
    void newOrder(ActionEvent event) throws IOException {

        String buttonSource = ((Control)event.getSource()).getId();
        for (int i = 0; i < tables.length; i++) {
            if(tables[i].equals(buttonSource)){
                String tableID = Integer.toString(i + 1);
                pref.put("tableID", tableID);
            }
        }
        System.out.println("Table clicked " + pref.get("tableID", "DEFAULT TABLE"));
        root.getChildren().setAll((Node) FXMLLoader.load(getClass().getResource("/sample/ui/order/orderFX.fxml")));
    }

}
