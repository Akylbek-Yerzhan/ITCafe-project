package sample.ui.bill;

import com.jfoenix.controls.JFXDatePicker;
import com.jfoenix.controls.JFXTextField;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import sample.model.Bill;
import sample.model.Category;
import sample.model.Food;
import sample.model.SQLConnection;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.prefs.Preferences;

public class BillController {
    Preferences pref = Preferences.userRoot().node("/sample");
    SimpleDateFormat DTF = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    SimpleDateFormat DF = new SimpleDateFormat("yyyy-MM-dd");
    Bill bill;

    public BillController(Bill bill) {
        this.bill = bill;
    }

    @FXML
    public AnchorPane root;

    @FXML
    private Label exitButton;

    @FXML
    private Text nameText;

    @FXML
    private JFXTextField hotNameTF;

    @FXML
    private JFXTextField freshNameTF;

    @FXML
    private JFXTextField drinkTF;

    @FXML
    public JFXTextField dateTF;

    @FXML
    private JFXTextField waiterBillTF;

    @FXML
    private Label hotPriceLabel;

    @FXML
    private Label freshPriceLabel;

    @FXML
    private Label drinkPriceLabel;

    @FXML
    private Label totalPriceLabel;

    @FXML
    public void initialize() throws IOException {
        hotPriceLabel.setText("");
        freshPriceLabel.setText("");
        drinkPriceLabel.setText("");
        nameText.setText("Bill №" + bill.getBillID());

        for (Food f : bill.getOrder()) {
            System.out.println(f.getFoodName());
            if (f.getCategory() == Category.Hot) {
                hotNameTF.setText(f.getFoodName());
                hotPriceLabel.setText(f.getFoodPrice() + "$");
            } else if (f.getCategory() == Category.Fresh) {
                freshNameTF.setText(f.getFoodName());
                freshPriceLabel.setText(f.getFoodPrice() + "$");
            } else if (f.getCategory() == Category.Drink) {
                drinkTF.setText(f.getFoodName());
                drinkPriceLabel.setText(f.getFoodPrice() + "$");
            }

        }
        dateTF.setText(DTF.format(bill.getDate()));
        waiterBillTF.setText(bill.getWaiter().getName());
        totalPriceLabel.setText(bill.getTotalPrice() + "$");
        File file= new File("src\\sample\\bill.txt");
        if (file.exists()) {
            String table = pref.get("tableID", "");
            if (bill.getOrder().size() == 1) {
                Food f = bill.getOrder().get(0);
                printToFile(String.valueOf(bill.getBillID()),table, f.getFoodName(), f.getFoodPrice() + "$", bill.getWaiter().getName(), DTF.format(bill.getDate()), bill.getTotalPrice() + "$");
            } else if (bill.getOrder().size() == 2) {
                Food f = bill.getOrder().get(0);
                Food f1 = bill.getOrder().get(1);
                printToFile(String.valueOf(bill.getBillID()),table, f.getFoodName(), f.getFoodPrice() + "$", f1.getFoodName(), f1.getFoodPrice() + "$", bill.getWaiter().getName(), DTF.format(bill.getDate()), bill.getTotalPrice() + "$");
            } else if (bill.getOrder().size() == 3) {
                Food f = bill.getOrder().get(0);
                Food f1 = bill.getOrder().get(1);
                Food f2 = bill.getOrder().get(2);
                printToFile(String.valueOf(bill.getBillID()),table, f.getFoodName(),  f1.getFoodName(), f2.getFoodName(), f.getFoodPrice() + "$", f1.getFoodPrice() + "$", f2.getFoodPrice() + "$", bill.getWaiter().getName(), DTF.format(bill.getDate()), bill.getTotalPrice() + "$");
            }
        }
    }

    @FXML
    void exit(MouseEvent event) {
        Stage stage = (Stage) root.getScene().getWindow();
        stage.close();
    }

    void printToFile(String billNumber, String table, String food, String price, String waiterName, String date, String total) throws FileNotFoundException {
        String text = billNumber + ", " + table + " " + food + " " + price + " " + waiterName + " " + date + " " + total;
        try (PrintWriter out = new PrintWriter(new FileOutputStream(new File("src\\sample\\bill.txt"), true))) {
            out.println(text);
        }
    }

    void printToFile(String billNumber, String table, String food, String price, String food2, String price2, String waiterName, String date, String total) throws FileNotFoundException {
        String text = billNumber + ", " + table + " " + food + " " + price + ", " + food2 + " " + price2 + " " + waiterName + " " + date + " " + total;
        try (PrintWriter out = new PrintWriter(new FileOutputStream(new File("src\\sample\\bill.txt"), true))) {
            out.println(text);
        }
    }

    void printToFile(String billNumber, String table, String hotFood, String freshFood, String drink, String hotPrice, String freshPrice, String drinkPrice, String waiterName, String date, String total) throws FileNotFoundException {
        String text = billNumber + ", " + table + " " + hotFood + " " + hotPrice + ", " + freshFood + " " + freshPrice + ", " + drink + " " + drinkPrice + " " + waiterName + " " + date + " " + total;
        try (PrintWriter out = new PrintWriter(new FileOutputStream(new File("src\\sample\\bill.txt"), true))) {
            out.println(text);
        }
    }

}
