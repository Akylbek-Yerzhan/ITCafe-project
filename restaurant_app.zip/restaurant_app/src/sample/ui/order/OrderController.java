package sample.ui.order;

import com.jfoenix.controls.JFXButton;
import com.jfoenix.controls.JFXComboBox;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import sample.model.*;
import sample.ui.bill.BillLoader;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.prefs.Preferences;

public class OrderController {
    Preferences pref = Preferences.userRoot().node("/sample");
    ArrayList<Food> foodList;
    ArrayList<Food> orderList = new ArrayList<Food>();
    Bill bill;

    @FXML
    public AnchorPane root;

    @FXML
    private Label exitButton;

    @FXML
    private Text nameText;

    @FXML
    private JFXButton logoutButton;

    @FXML
    private JFXComboBox<String> hotFoodCB;

    @FXML
    private JFXComboBox<String> freshFoodCB;

    @FXML
    private JFXComboBox<String> drinkCB;

    @FXML
    public Label hotPriceLabel;

    @FXML
    public Label freshPriceLabel;

    @FXML
    public Label drinkPriceLabel;

    @FXML
    private JFXButton orderButton;

    @FXML
    private Hyperlink cancelButton;

    @FXML
    public void initialize() throws SQLException {
        String waiterLogin = pref.get("login", "DEFAULT VALUE");
        nameText.setText(SQLConnection.getWaiterName(waiterLogin));

        freshPriceLabel.setText("");
        hotPriceLabel.setText("");
        drinkPriceLabel.setText("");
        foodList = SQLConnection.getFoodArray();
        for (Food food : foodList) {
            if (food.getCategory() == Category.Hot)
                hotFoodCB.getItems().add(food.getFoodName());
            else if (food.getCategory() == Category.Drink)
                drinkCB.getItems().add(food.getFoodName());
            else if (food.getCategory() == Category.Fresh)
                freshFoodCB.getItems().add(food.getFoodName());
        }
        hotFoodCB.setOnAction(actionEvent -> {
            for (Food f : foodList) {
                if (f.getFoodName().equals(hotFoodCB.getValue()))
                    hotPriceLabel.setText(String.valueOf(f.getFoodPrice() + "$"));
            }
        });

        freshFoodCB.setOnAction(actionEvent -> {
            for (Food f : foodList) {
                if (f.getFoodName().equals(freshFoodCB.getValue()))
                    freshPriceLabel.setText(String.valueOf(f.getFoodPrice() + "$"));
            }
        });

        drinkCB.setOnAction(actionEvent -> {
            for (Food f : foodList) {
                if (f.getFoodName().equals(drinkCB.getValue()))
                    drinkPriceLabel.setText(String.valueOf(f.getFoodPrice() + "$"));
            }
        });

    }

    @FXML
    void backToTable(ActionEvent event) {
        try {
            root.getChildren().setAll((Node) FXMLLoader.load(getClass().getResource("/sample/ui/table/tableFX.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void exit(MouseEvent event) {
        System.exit(0);
    }

    @FXML
    void logout(ActionEvent event) throws IOException {
        System.out.println(pref.get("login", "DEFAULT VALUE") + " successfully logout!");
        pref.put("login", "");

        root.getChildren().setAll((Node) FXMLLoader.load(getClass().getResource("/sample/ui/welcome/welcomeFX.fxml")));
    }

    @FXML
    void makeOrder(ActionEvent event) throws Exception {
        orderList.clear();
        for (Food f : foodList) {
            if (f.getFoodName().equals(freshFoodCB.getValue()) || f.getFoodName().equals(hotFoodCB.getValue()) || f.getFoodName().equals(drinkCB.getValue())){
                orderList.add(f);
        }
        }
        if(!orderList.isEmpty()){
            Date date = new Date();
            String waiterLogin = pref.get("login", "");
            String tableID = pref.get("tableID", "1");
            Waiter currentWaiter = SQLConnection.getWaiter(waiterLogin);

            Bill bill = new Bill(orderList, date, currentWaiter, Integer.parseInt(tableID));
            System.out.println(bill.toString());

            int billId = SQLConnection.newBill(bill);
            bill.setBillID(billId);
            //Set new Stage
            BillLoader billLoader = new BillLoader(bill);
            Stage stage = new Stage();
            billLoader.start(stage);
        }

    }

}
