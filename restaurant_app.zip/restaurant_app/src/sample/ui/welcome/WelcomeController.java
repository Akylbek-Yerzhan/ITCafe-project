package sample.ui.welcome;

import com.jfoenix.controls.JFXButton;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;

import java.io.IOException;

public class WelcomeController {


    @FXML
    public AnchorPane root;

    @FXML
    private JFXButton redButton;

    @FXML
    private JFXButton waiterButton;

    @FXML
    private Label exitButton;

    @FXML
    void exit(MouseEvent event) { System.exit(0); }

    @FXML
    void loginAdmin(ActionEvent event) {
        try {
            root.getChildren().setAll((Node) FXMLLoader.load(getClass().getResource("/sample/ui/login_admin/adminLoginFX.fxml")));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    void loginWaiter(ActionEvent event) {
        try {
            root.getChildren().setAll((Node) FXMLLoader.load(getClass().getResource("/sample/ui/login_waiter/loginFX.fxml")));

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
