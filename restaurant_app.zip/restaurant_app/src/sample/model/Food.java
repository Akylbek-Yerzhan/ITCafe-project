package sample.model;


public class Food {
    private String foodName;
    private int foodPrice;
    private Category category;


    public Food(String foodName, int foodPrice, Category category){
        this.foodName = foodName;
        this.foodPrice = foodPrice;
        this.category = category;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public int getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(int foodPrice) {
        this.foodPrice = foodPrice;
    }

    public Category getCategory() {
        return category;
    }

    public void setCategory(Category category) {
        this.category = category;
    }
}
