package sample.model;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import java.util.prefs.Preferences;

public class SQLConnection {
    static Connection connection = null;
    static String dbName = "mydb";
    static String url = "jdbc:mysql://localhost/" + dbName + "?serverTimezone=Asia/Almaty&useSSL=false";
    static String username = "root";
    static String password = "";
    static String driver = "com.mysql.cj.jdbc.Driver";
    static SimpleDateFormat DTF = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
    SimpleDateFormat DF = new SimpleDateFormat("yyyy-MM-dd");

    public static void connectDB() {
        try {
            Class.forName(driver);
            connection = DriverManager.getConnection(url, username, password);
            System.out.println("Connection to DataBase successfully!");
        } catch (SQLException | ClassNotFoundException throwable) {
            throwable.printStackTrace();
        }
    }

    public static boolean loginWaiter(String login, String pass) throws SQLException {
        PreparedStatement preparedStatement = connection.prepareStatement("SELECT login FROM waiter WHERE login = ? AND pass = ?");
        preparedStatement.setString(1, login);
        preparedStatement.setString(2, pass);
        ResultSet rs = preparedStatement.executeQuery();

        if (rs.next()) {
            if (login.equals(rs.getString("login"))) {
                Preferences pref = Preferences.userRoot().node("/sample");
                pref.put("login", login);
                String preference = pref.get("login", "yourPreferenceValue");

                System.out.println(preference + " successfully login!");
                return true;
            }
        }
        return false;
    }

    public static String getWaiterName(String login) throws SQLException {
        PreparedStatement stmt = connection.prepareStatement("SELECT waiterName FROM waiter WHERE login = ?");
        stmt.setString(1, login);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            return rs.getString("waiterName");
        }
        return "DEFAULT VALUE";
    }

    public static Waiter getWaiter(String login) throws SQLException {
        PreparedStatement stmt = connection.prepareStatement("SELECT * FROM waiter WHERE login = ?");
        stmt.setString(1, login);
        ResultSet rs = stmt.executeQuery();
        if (rs.next()) {
            int waiterId = rs.getInt("waiterId");
            String waiterName = rs.getString("waiterName");
            String waiterLogin = rs.getString("login");
            String waiterPass = rs.getString("pass");
            Date date = rs.getDate("expiredDate");
            return new Waiter(waiterId, waiterLogin, waiterPass, waiterName, date);
        }
        return null;
    }

    public static ArrayList<Food> getFoodArray() throws SQLException {
        PreparedStatement stmt = connection.prepareStatement("SELECT foodName, foodPrice, category FROM food");
        ResultSet rs = stmt.executeQuery();
        ArrayList<Food> foodArrayList = new ArrayList<Food>();
        while (rs.next()) {
            boolean categoryCorrect = false;
            String foodName = rs.getString("foodName");
            int foodPrice = rs.getInt("foodPrice");
            String category = rs.getString("category");

            for (Category c : Category.values()) {
                if (category.equals(c.toString()))
                    categoryCorrect = true;
            }
            if (categoryCorrect) {
                Food food = new Food(foodName, foodPrice, Category.valueOf(category));
                foodArrayList.add(food);
            }
        }

        return foodArrayList;
    }

    public static int newBill(Bill bill) throws SQLException {
        java.util.Date date = bill.getDate();
        int table = bill.getTable();
        int waiterID = bill.getWaiter().getWaiterID();
        PreparedStatement insertBill = connection.prepareStatement("INSERT INTO bill(curdate,curtable,waiterId) VALUES(?,?,?)");
        insertBill.setString(1, DTF.format(date));
        insertBill.setInt(2, table);
        insertBill.setInt(3, waiterID);
        int result1 = insertBill.executeUpdate();


        PreparedStatement selectBillId = connection.prepareStatement("SELECT billId FROM BILL WHERE curdate = ? AND curtable = ? AND waiterId = ?");
        selectBillId.setString(1, DTF.format(date));
        selectBillId.setInt(2, table);
        selectBillId.setInt(3, waiterID);
        ResultSet billID = selectBillId.executeQuery();
        if (billID.next()) {
            for (Food f : bill.getOrder()) {
                PreparedStatement insertOrders = connection.prepareStatement("INSERT INTO ORDERS(billId, foodName) VALUES(?,?)");
                insertOrders.setInt(1, billID.getInt("billId"));
                insertOrders.setString(2, f.getFoodName());
                int result2 = insertOrders.executeUpdate();
                System.out.println("Insert " + result2 + " row");
            }
            return billID.getInt("billId");
        }
        return 0;
    }
}