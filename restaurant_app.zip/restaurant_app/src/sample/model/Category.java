package sample.model;

public enum Category {
    Drink, Hot, Fresh
}
