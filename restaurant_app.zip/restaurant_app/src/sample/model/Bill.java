package sample.model;

import java.util.ArrayList;
import java.util.Date;

public class Bill {
    private int billID;
    private ArrayList<Food> order;
    private Date date;
    private Waiter waiter;
    private int table;
    private boolean completed;

    public Bill(ArrayList<Food> order, Date date, Waiter waiter, int table) {
        this.order = order;
        this.date = date;
        this.waiter = waiter;
        this.table = table;
        this.completed = false;
    }

    public Waiter getWaiter() {
        return waiter;
    }

    public void setWaiter(Waiter waiter) {
        this.waiter = waiter;
    }

    public ArrayList<Food> getOrder() {
        return order;
    }

    public void setOrder(ArrayList<Food> order) {
        this.order = order;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void addFood(Food food){
        this.order.add(food);
    }

    public void removeFood(Food food){
        this.order.remove(food);
    }

    public int getTable() {
        return table;
    }

    public void setTable(int table) {
        this.table = table;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public int getBillID() {
        return billID;
    }

    public void setBillID(int billID) {
        this.billID = billID;
    }

    public int getTotalPrice() {
        int total = 0;
        for(Food f : this.order){
            total += f.getFoodPrice();
        }
        return total;
    }
}
