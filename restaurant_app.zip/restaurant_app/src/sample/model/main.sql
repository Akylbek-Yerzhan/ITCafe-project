SELECT * FROM waiter;

# CREATE TABLE IF NOT EXISTS `admin`
# (
#     adminId int          NOT NULL AUTO_INCREMENT PRIMARY KEY,
#     login   varchar(45)  NOT NULL,
#     pass    varchar(100) NOT NULL
# );
#
# CREATE TABLE IF NOT EXISTS waiter
# (
#     waiterId    int NOT NULL AUTO_INCREMENT PRIMARY KEY,
#     login       varchar(45)  NOT NULL,
#     pass        varchar(100) NOT NULL,
#     waiterName  varchar(45)  NOT NULL,
#     expiredDate date         NOT NULL
# );
#
# CREATE TABLE IF NOT EXISTS bill
# (
#     billId    int  NOT NULL AUTO_INCREMENT PRIMARY KEY,
#     curdate   DATE NOT NULL,
#     curtable  int  NOT NULL,
#     completed boolean default false,
#     waiterId  int  NOT NULL,
#     FOREIGN KEY (waiterId) REFERENCES waiter (waiterId)
# );
#
# CREATE TABLE IF NOT EXISTS food
# (
#     foodName  varchar(45) NOT NULL PRIMARY KEY,
#     foodPrice double      NOT NULL,
#     category  varchar(45) NOT NULL
# );