package sample.model;

import java.util.Date;

public class Waiter extends User {
    private int waiterID;
    private String name;
    final Date expiredDate;

    public Waiter(String login, String password, String name) {
        super(login, password);
        this.name = name;
        this.expiredDate = new Date();
    }

    public Waiter(int waiterID, String login, String password, String name, Date date){
        super(login, password);
        this.waiterID = waiterID;
        this.name = name;
        this.expiredDate = date;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getWaiterID() {
        return waiterID;
    }
}
