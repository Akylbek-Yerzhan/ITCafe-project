package sample.model;

public class Admin extends User{
    private int index;
    public Admin(String login, String password) {
        super(login, password);
    }

    public int getIndex() {
        return index;
    }
}
